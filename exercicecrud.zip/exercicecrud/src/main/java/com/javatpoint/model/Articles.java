package com.javatpoint.model;
  
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;  
import javax.persistence.Table;  

@Entity  
@Table(name="tbl_article")
public class Articles {
	
	@Id   
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int articleid;    
	private String articlename;  
	private int quantity;  
	private int price;  
	
	public Articles() {
		
	}

	public Articles(int articleid, String articlename, int quantity, int price) {
		super();
		this.articleid = articleid;
		this.articlename = articlename;
		this.quantity = quantity;
		this.price = price;
	}
	
	public int getArticleid()   
	{  
	return articleid;  
	}  
	public void setArticleid(int articleid)   
	{  
	this.articleid = articleid;  
	}  
	public String getArticlename()  
	{  
	return articlename;  
	}  
	public void setArticlename(String articlename)   
	{  
	this.articlename = articlename;  
	}  
	public int getQuantity()   
	{  
	return quantity;  
	}  
	public void setQuantity(int quantity)   
	{  
	this.quantity = quantity;  
	}  
	public int getPrice()   
	{  
	return price;  
	}  
	public void setPrice(int price)   
	{  
	this.price = price;  
	} 

}
