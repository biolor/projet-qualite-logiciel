package com.javatpoint.repository;  

import org.springframework.data.repository.CrudRepository;  
import com.javatpoint.model.Articles;  

  
public interface ArticlesRepository extends CrudRepository<Articles, Integer> {
	
}  
