package com.javatpoint.controller;
 
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.PutMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RestController;  
import com.javatpoint.model.Articles;
import com.javatpoint.service.ArticlesService;  

@RestController  
public class ArticlesController {
	
	@Autowired  
	ArticlesService articlesService;   
	@GetMapping("/article")  
	private List<Articles> getAllArticles()   
	{  
	return articlesService.getAllArticles();  
	}    
	@GetMapping("/article/{articleid}")  
	private Articles getArticles(@PathVariable("articleid") int articleid)   
	{  
	return articlesService.getArticlesById(articleid);  
	}  
	@DeleteMapping("/article/{articleid}")  
	private void deleteArticle(@PathVariable("articleid") int articleid)   
	{  
	articlesService.delete(articleid);  
	}    
	@PostMapping("/articles")  
	private int saveArticle(@RequestBody Articles articles)   
	{  
	articlesService.saveOrUpdate(articles);  
	return articles.getArticleid();  
	}  
	@PutMapping("/articles")  
	private Articles update(@RequestBody Articles articles)   
	{  
	articlesService.saveOrUpdate(articles);  
	return articles;  
	}  

}
