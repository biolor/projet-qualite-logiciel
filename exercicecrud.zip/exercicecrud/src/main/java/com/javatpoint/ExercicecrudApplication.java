package com.javatpoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicecrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicecrudApplication.class, args);
	}

}
