package com.javatpoint.service;

import java.util.ArrayList;  
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
import com.javatpoint.model.Articles;  
import com.javatpoint.repository.ArticlesRepository;  

@Service  
public class ArticlesService {
	
	@Autowired  
	ArticlesRepository articlesRepository;  
	public List<Articles> getAllArticles()   
	{  
	List<Articles> articles = new ArrayList<Articles>();  
	articlesRepository.findAll().forEach(articles1 -> articles.add(articles1));  
	return articles;  
	}  
	public Articles getArticlesById(int id)   
	{  
	return articlesRepository.findById(id).get();  
	}  
	public void saveOrUpdate(Articles articles)   
	{  
	articlesRepository.save(articles);  
	}  
	public void delete(int id)   
	{  
	articlesRepository.deleteById(id);  
	}  
	public void update(Articles articles, int articleid)   
	{  
	articlesRepository.save(articles);  
	}  

}
